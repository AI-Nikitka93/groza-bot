import Redis from 'ioredis';
import { ENV } from '../env';

export const redis = new Redis(ENV.REDIS_URL);

export async function checkRateLimitBatch(userIds: number[], eventType: 'critical' | 'warning', cooldownSec: number): Promise<number[]> {
  if (userIds.length === 0) return [];
  const pipeline = redis.pipeline();
  userIds.forEach(id => {
    const key = `ratelimit:${id}:${eventType}`;
    pipeline.set(key, '1', 'EX', cooldownSec, 'NX');
  });
  const results = await pipeline.exec();
  
  const allowedUsers: number[] = [];
  if (results) {
    userIds.forEach((id, index) => {
      const res = results[index];
      if (!res[0] && res[1] === 'OK') {
        allowedUsers.push(id);
      }
    });
  }
  return allowedUsers;
}
