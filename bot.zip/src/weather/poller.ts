import { getAllUsers } from '../db/tembo';
import { checkRateLimitBatch } from '../cache/upstash';
import { telegramQueue } from '../alerting/queue';
import { ENV } from '../env';

const BATCH_SIZE = 50; // max coords per request to avoid URL too long
const ALERT_COOLDOWN_SEC = 1800; // 30 mins

export async function checkWeatherForUsers() {
  try {
    const users = await getAllUsers();
    if (users.length === 0) return;

    for (let i = 0; i < users.length; i += BATCH_SIZE) {
      const batch = users.slice(i, i + BATCH_SIZE);
      await processBatch(batch);
    }
  } catch (error) {
    console.error('Error in checkWeatherForUsers:', error);
  }
}

async function processBatch(users: {id: number, lat: number, lon: number}[]) {
  const lats = users.map(u => u.lat).join(',');
  const lons = users.map(u => u.lon).join(',');
  
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lats}&longitude=${lons}&minutely_15=weather_code&forecast_minutely_15=4&timezone=auto`;
  
  try {
    const res = await fetch(url);
    const data = await res.json();
    
    // If only 1 location, data is an object, if multiple, it's an array
    const locationsData = Array.isArray(data) ? data : [data];
    
    const usersInDanger: number[] = [];

    for (let i = 0; i < locationsData.length; i++) {
      const locationInfo = locationsData[i];
      if (locationInfo && locationInfo.minutely_15 && locationInfo.minutely_15.weather_code) {
        // Check next 4 periods (next 1 hour)
        const codes: number[] = locationInfo.minutely_15.weather_code;
        const hasThunderstorm = codes.some(code => code >= 95 && code <= 99);
        
        if (hasThunderstorm) {
          usersInDanger.push(users[i].id);
        }
      }
    }

    if (usersInDanger.length > 0) {
      const allowedToAlert = await checkRateLimitBatch(usersInDanger, 'warning', ALERT_COOLDOWN_SEC);
      for (const userId of allowedToAlert) {
        const text = `⚠️ Внимание: Над вами прогнозируется гроза в ближайшие 30-40 минут!\n\nРекомендуем найти укрытие.`;
        await telegramQueue.add('alert', { userId, text });
      }
    }

  } catch (error) {
    console.error('Error fetching Open-Meteo:', error);
  }
}

export function startWeatherPoller() {
  console.log('Starting Open-Meteo weather poller...');
  // Check every 10 minutes
  setInterval(checkWeatherForUsers, 10 * 60 * 1000);
  // Initial check
  checkWeatherForUsers();
}
